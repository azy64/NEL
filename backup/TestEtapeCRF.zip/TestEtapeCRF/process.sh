#!/bin/bash

cat QuaeroEtape/bio/* > QuaeroEtape.bio
cat QuaeroEtape.bio | head -n 100000 > QuaeroEtape-sample.bio
wapiti train -p patterns.txt QuaeroEtape-sample.bio QuaeroEtape.mdl
cat test.txt | tree-tagger-french | cut -f 1 > test-tokens.txt
wapiti label -m QuaeroEtape.mdl test-tokens.txt test-tokens-labels.txt
